This folder stores orchestration execution records in `executions.json`.

Do not edit manually unless debugging a PoC.
